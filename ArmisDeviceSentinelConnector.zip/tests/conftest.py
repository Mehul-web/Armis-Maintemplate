import pytest


mp = pytest.MonkeyPatch()
mp.setenv("ArmisSecretKey", "abc")
mp.setenv("ArmisURL", "abc")
mp.setenv("AzureWebJobsStorage", "abc")
mp.setenv("WorkspaceID", "abc")
mp.setenv("WorkspaceKey", "abc")
mp.setenv("ArmisDeviceTableName", "abc")
mp.setenv("AvoidDuplicates", "abc")

HTTP_ERRORS = {
    400: "Armis Device Connecter: Bad request: Missing aql Parameter.",
    401: "Armis Device Connecter: Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Armis Device Connecter: Access Token not found. Please check Key.",
    "HOST_CONNECTION_ERROR": "Armis Device Connecter: Invalid host while verifying 'Armis Account'.",
}
data_device_from = 0
retry_device_token = 0
