import pytest
import datetime
import ArmisDeviceSentinelConnector.__init__ as a
import logging
import requests
import json
from .conftest import HTTP_ERRORS
from .conftest import ERROR_MESSAGES
from .conftest import data_device_from
from .conftest import retry_device_token
from Exceptions.ArmisExceptions import ArmisException

access_token_var = "/access_token/"
search_key_var = "/search/"
aql = "in:devices"
fields = "accessSwitch,category,firstSeen,id,ipAddress,lastSeen,macAddress,manufacturer,model,name,operatingSystem,operatingSystemVersion,riskLevel,sensor,site,tags,type,user,visibility,serialNumber,plcModule,purdueLevel,firmwareVersion"


def get_init_false(self):
    """This method will initialize object of class"""
    self._link = None
    self._header = {}
    self._secret_key = "abc"


def get_init_false_no_secret(self):
    """This method will initialize object of class"""
    self._link = "abc"
    self._header = {}
    self._secret_key = None


def get_init_false_link(self):
    """This method will initialize object of class"""
    self._link = ""
    self._header = {}
    self._secret_key = (
        "2b1862655e439fd19eff0961fd55bfceb50790b81aea6af173cc450984115e75"
    )


def get_init_false_secret_key(self):
    """It will check" with false secret key"""
    self._link = "https://integration-crestdata.armis.com/api/v1"
    self._header = {}
    self._secret_key = ""


def get_init_true_all(self):
    """It will check with all true argument"""
    self._link = "https://integration-crestdata.armis.com/api/v1"
    self._header = {}
    self._secret_key = (
        "2b1862655e439fd19eff0961fd55bfceb50790b81aea6af173cc450984115e75"
    )


def get_get_access_token(self, armis_link_suffix):
    """
    This method will fetch the access token using api and
    set it in header for further use

    Args:
        armis_link_suffix (String): This variable will be suffix/add-on to the\
             link.
    """
    if self._secret_key is not None and self._link is not None:
        parameter = {"secret_key": self._secret_key}
        try:
            response = requests.post((self._link + armis_link_suffix), params=parameter)
            if response.status_code == 200:
                logging.info("Getting Access Token.")
                _access_token = json.loads(response.text)["data"]["access_token"]
                self._header.update({"Authorization": _access_token})
            elif response.status_code == 400:
                raise ArmisException(
                    "Bad request, please check the arguments you passed."
                )

            else:
                raise ArmisException(
                    "Error while generating the access token. Error code: {}.\
                        ".format(
                        response.status_code
                    )
                )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException("Error while generating the access token.")

    else:
        raise ArmisException("The secret key or link has not been initialized.")


def test_false():
    """It will check with all false things for access token"""
    a.ArmisDevice._get_access_token = get_get_access_token
    with pytest.raises(Exception):
        a.ArmisDevice.__init__ = get_init_false
        abc = a.ArmisDevice()
        abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        a.ArmisDevice.__init__ = get_init_false_no_secret
        abc = a.ArmisDevice()
        abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        a.ArmisDevice.__init__ = get_init_false_link
        abc = a.ArmisDevice()
        abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        a.ArmisDevice.__init__ = get_init_false_secret_key
        abc = a.ArmisDevice()
        abc._get_access_token(access_token_var)
    a.ArmisDevice.__init__ = get_init_true_all
    abc = a.ArmisDevice()
    abc._get_access_token(access_token_var)
    print(abc._header)


def test_get_data_with_no_parameters():
    """It will check get data with no parameter"""
    a.ArmisDevice.__init__ = get_init_true_all
    abc = a.ArmisDevice()
    abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        abc._get_device_data()


def test_get_data_with_one_parameter():
    """It will check get data with one parameter"""
    a.ArmisDevice.__init__ = get_init_true_all
    abc = a.ArmisDevice()
    abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        abc._get_data(search_key_var)


def get_get_device_data(self, armis_link_suffix, parameter):
    """get_get_device_data is used to get data using api.
        Monkey Patching of _get_device_data method

    Args:
        self: Armis object.
        armis_link_suffix (String): will be containing the other part of link.
        parameter (json): will contain the json data to sends to parameter to get data from REST API.

    """
    try:
        global data_device_from, retry_device_token

        response = requests.get(
            (self._link + armis_link_suffix), params=parameter, headers=self._header
        )
        if response.status_code == 200:
            logging.info("Getting data with response code %s", response.status_code)
            results = json.loads(response.text)
            if (
                "data" in results
                and "results" in results["data"]
                and "total" in results["data"]
                and "count" in results["data"]
                and "next" in results["data"]
            ):

                data = results["data"]["results"]

                logging.info(
                    "From this length %s we are fetching data.", data_device_from
                )
                data_device_from = results["data"]["next"]
                logging.info("Next page will be from %s", data_device_from)
                current_time = data[-1]["lastSeen"][:-13]
                return response, current_time
            else:
                raise ArmisException("There are no proper keys in data.")

        elif response.status_code == 400:
            raise ArmisException(HTTP_ERRORS[400])

        elif response.status_code == 401 and retry_device_token < 1:
            logging.info("Retry number: {}".format(str(retry_device_token)))
            retry_device_token += 1
            print(retry_device_token)
            logging.error(HTTP_ERRORS[401])
            logging.info("Generating Access Token Again!")
            self._get_access_token_device(access_token_var)
            return self._get_device_data(armis_link_suffix, parameter)
        else:
            raise ArmisException(
                "Error while fetching data. Status Code:{} Error Message:{}.".format(
                    response.status_code, response.text
                )
            )

    except requests.exceptions.ConnectionError:
        logging.error(ERROR_MESSAGES["HOST_CONNECTION_ERROR"])
        raise ArmisException("Connection error while getting data from activity api.")

    except requests.exceptions.RequestException as request_err:
        logging.error(request_err)
        raise ArmisException("Request error while getting data from activity api.")

    except ArmisException as err:
        print(err)
        raise ArmisException("Error while getting data from device api.")


def test_get_device_data_with_all_scenarios():
    """It will check get activity with all scenario"""
    parameter_device = {
        "aql": "in:activty",
        "orderBy": "lastSeen",
        "fields": fields,
    }
    a.ArmisDevice.__init__ = get_init_true_all
    abc = a.ArmisDevice()
    abc._get_access_token(access_token_var)
    with pytest.raises(Exception):
        abc._get_device_data(search_key_var, parameter_device)

    parameter_device["aql"] = aql
    with pytest.raises(Exception):
        abc._get_device_data("/searh/", parameter_device)

    a.ArmisDevice._get_device_data = get_get_device_data
    abc = a.ArmisDevice()
    res, d = abc._get_device_data(search_key_var, parameter_device)
    assert res.status_code == 200

    a.ArmisDevice._get_device_data = get_get_device_data
    abc = a.ArmisDevice()
    with pytest.raises(Exception):
        res, d = abc._get_device_data(search_key_var, parameter_device)


def monkey_data_table_not_exist(
    self, type_data, is_table_not_exist, data_device_from, last_time=None
):
    """Monkey patching class for data table not exist"""
    try:
        self._get_access_token_device(access_token_var)
        now = datetime.datetime.utcnow()
        curr_date = (now + datetime.timedelta(days=-4)).strftime("%Y-%m-%dT%H:%M:%S")
        if is_table_not_exist:
            aql_data = """{} before:{}""".format(type_data["aql"], curr_date)
        else:
            aql_data = """{} after:{} before:{}""".format(
                type_data["aql"], last_time, curr_date
            )
        type_data["aql"] = aql_data
        logging.info("aql data new " + str(type_data["aql"]))

        if data_device_from is not None:
            parameter_device = {
                "aql": type_data["aql"],
                "from": data_device_from,
                "orderBy": "lastSeen",
                "length": 1000,
                "fields": type_data["fields"],
            }

            res, timed = self._get_device_data(search_key_var, parameter_device)
            return res, timed, type_data["aql"]
        logging.info("StateManager Time_Data Posted Successfully!")
    except ArmisException as elt:
        print(elt)
        raise ArmisException("Error while processing the data.")


def test_table_not_exist_success():
    """Monkey patching class for data table not exist"""
    a.ArmisDevice.__init__ = get_init_true_all
    a.ArmisDevice._data_table_not_exist = monkey_data_table_not_exist
    abc = a.ArmisDevice()
    data_device_from = 0
    parameter_device = {
        "aql": aql,
        "orderBy": "lastSeen",
        "fields": fields,
    }
    abc._data_table_not_exist(parameter_device, True, data_device_from)


def test_table_not_exist_fail_wrong_parameter():
    """It will check test table not exist with wrong parameter"""
    a.ArmisDevice.__init__ = get_init_true_all
    a.ArmisDevice._data_table_not_exist = monkey_data_table_not_exist
    abc = a.ArmisDevice()
    data_device_from = 0
    parameter_device = {
        "aql": "in:device",
        "orderBy": "lastSeen",
        "fields": fields,
    }
    with pytest.raises(Exception):
        (abc._data_table_not_exist(parameter_device, True, data_device_from))


def test_table_not_exist_check_proper_date_formatting():
    """It will check proper date length"""
    a.ArmisDevice.__init__ = get_init_true_all
    a.ArmisDevice._data_table_not_exist = monkey_data_table_not_exist
    abc = a.ArmisDevice()
    data_device_from = 0
    parameter_device = {
        "aql": aql,
        "orderBy": "lastSeen",
        "fields": fields,
    }
    assert (
        len(abc._data_table_not_exist(parameter_device, True, data_device_from)[1])
        == 19
    )


def test_check_aql():
    """It will check aql build for getdata"""
    a.ArmisDevice.__init__ = get_init_true_all
    a.ArmisDevice._data_table_not_exist = monkey_data_table_not_exist
    abc = a.ArmisDevice()
    data_device_from = 0
    date_now = (
        datetime.datetime(2022, 3, 10, 12, 56, 54) + datetime.timedelta(-4)
    ).strftime("%Y-%m-%dT%H:%M:%S")
    parameter_device = {
        "aql": aql,
        "orderBy": "lastSeen",
        "fields": fields,
    }
    abc._get_access_token(access_token_var)
    res = abc._data_table_not_exist(
        parameter_device, False, data_device_from, str(date_now)
    )[2]
    assert "after:" in (res)
    assert "before:" in (res)
    parameter_device = {
        "aql": aql,
        "orderBy": "lastSeen",
        "fields": fields,
    }
    res1 = abc._data_table_not_exist(parameter_device, True, data_device_from)[2]
    assert "after:" not in (res1)


def test_false_but_none():
    """It will check given flag with false and none argument"""
    a.ArmisDevice.__init__ = get_init_true_all
    a.ArmisDevice._data_table_not_exist = monkey_data_table_not_exist
    abc = a.ArmisDevice()
    data_device_from = 0
    parameter_device = {
        "aql": aql,
        "orderBy": "lastSeen",
        "fields": fields,
    }
    # need to write raise ArmisException in except block
    with pytest.raises(Exception):
        abc._data_table_not_exist(parameter_device, False, data_device_from)
